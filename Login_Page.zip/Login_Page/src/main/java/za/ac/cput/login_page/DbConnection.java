
package za.ac.cput.login_page;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Sinalo Ngolozana (217211151)
 */

public class DbConnection {
    
    Connection con = null;
    
    public static Connection ConnectionDb() {
        try {
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc : sqlite:Database\\visitors.db");
            System.out.println("Connection Successful");
            return conn;
        }
        
        catch (Exception e) {
            System.out.println("Connection Unsuccessful" + e);
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
}
